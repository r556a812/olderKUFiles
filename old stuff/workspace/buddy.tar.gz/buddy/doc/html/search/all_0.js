var searchData=
[
  ['_5f_5flist_5fadd',['__list_add',['../list_8h.html#a8a28f150a191624bf6923a48cdace7e3',1,'list.h']]],
  ['_5f_5flist_5fdel',['__list_del',['../list_8h.html#a24b474717d65a296695e8b79b4adefda',1,'list.h']]],
  ['_5f_5flist_5fsplice',['__list_splice',['../list_8h.html#a25979c80a2d71dd02ada121a46c71a59',1,'list.h']]]
];
