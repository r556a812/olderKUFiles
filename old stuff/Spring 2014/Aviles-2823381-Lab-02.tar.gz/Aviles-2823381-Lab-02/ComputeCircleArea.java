/* -----------------------------------------------------------------------------
 *
 * File Name: CircleArea.java
 * Author: Richard Aviles r556a812@ku.edu
 * Assignment:   EECS-168/169 Lab 2
 * Description:  This program will compute the area of a circle with a hard-coded radius.
 * Date:02/04/15
 *
 ---------------------------------------------------------------------------- */
import java.util.Scanner;

public class ComputeCircleArea 
{
	public static void main(String[] args)
	{//Create a scanner object.
		Scanner input = new Scanner(System.in);
		
		//Declare the variables and constants.
				final double PI = 3.141592;
				double radius;
				double area;
				
				System.out.println("Enter the number for radius:");
				
				//Read the input from the keyboard.
				radius = input.nextDouble();
				
				//Calculate the area.
				area = PI*radius*radius;
				
				System.out.println("The area for the circle of radius " + radius + " is " + area);
				
				
				
				
	}

}
