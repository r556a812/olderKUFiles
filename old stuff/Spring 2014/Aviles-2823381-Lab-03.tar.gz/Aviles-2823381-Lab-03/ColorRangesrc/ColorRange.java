import java.util.Scanner;
public class ColorRange 
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		//Declare the variables and constraints.
		double wavelength;
		
		System.out.println("Enter a wavelength in nm:");
		
		//Receive the users wavelength.
		wavelength = input.nextDouble();
		
		//If-else statements to give the right color
		if (wavelength<380)
		{System.out.println("The entered wavelength is not a part of the visible spectrum.");
		}
		else if (wavelength<450)
		{System.out.println("The color is Violet.");
		
		}
		else if (wavelength<495)
		{System.out.println("The color is Blue.");
		}
		else if (wavelength<570)
		{System.out.println("The color is Green.");
		}
		else if (wavelength<590)
		{System.out.println("The color is Yellow.");
		}
		else if (wavelength<620)
		{System.out.println("The color is Orange.");
		
		}
		else if (wavelength<750)
		{System.out.println("The color is Red.");
		
		}
		else if (wavelength>=750)
		{System.out.println("The entered wavelength is not a part of the visible spectrum.");
		
		}
	}
}
