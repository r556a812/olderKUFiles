import java.util.Scanner;
public class UserLoop 
{
	public static void main(String[] args)
	{
	Scanner input = new Scanner(System.in);
	
	int start;
	int end;
	
	System.out.println("Input a start value (included): ");
	
	start = input.nextInt();
	
	System.out.println("Input an ending value (excluded): ");
	
	end = input.nextInt();
	
	if (start > end)
	{System.out.println("Invalid input");
	}
	for (int i = start; i < end; i = i+1 )
	{System.out.println(i);
	
	}
	}
	
	


}
