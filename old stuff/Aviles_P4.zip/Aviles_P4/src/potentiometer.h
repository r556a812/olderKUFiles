/*
 * potentiometer.h
 *
 *  Created on: Mar 24, 2016
 *      Author: raviles
 */

#ifndef SRC_POTENTIOMETER_H_
#define SRC_POTENTIOMETER_H_

#include "system.h"
#include "queue.h"

extern QueueHandle_t queue;
extern void POTENTIOMETERTask(void*);

#endif /* SRC_POTENTIOMETER_H_ */
