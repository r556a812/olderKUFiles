The utilities here are a subset of those in the full cryph toolkit.

The Matrix3x3 class is here mostly to support the Matrix4x4 class. OpenGL
programs will generally never need anything directly from Matrix3x3.
