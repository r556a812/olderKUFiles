/*
 * testAssembly.h
 *
 *  Created on: Nov 2, 2015
 *      Author: btorrenc
 */

#ifndef SRC_TESTASSEMBLY_H_
#define SRC_TESTASSEMBLY_H_

extern void testAssemblyTask(void*);

#endif /* SRC_TESTASSEMBLY_H_ */
