/*
 * speaker.h
 *
 *  Created on: Mar 2, 2016
 *      Author: raviles
 */


#ifndef EECS_388_P2_SRC_SPEAKER_H_
#define EECS_388_P2_SRC_SPEAKER_H_

extern unsigned long frequency;
extern void SPEAKERTask(void*);

#endif /* EECS_388_P2_SRC_SPEAKER_H_ */
