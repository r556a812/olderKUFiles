/* Definitions of structures and function prototypes */

#ifndef _DEFS_3_H
#define _DEFS_3_H

struct A{
  int in_var1, in_var2;
};

int my_mul(int, int);

#endif
