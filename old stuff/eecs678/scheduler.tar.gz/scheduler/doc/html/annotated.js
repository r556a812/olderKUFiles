var annotated =
[
    [ "job_t", "structjob__t.html", null ],
    [ "priqueue_t", "structpriqueue__t.html", null ]
];