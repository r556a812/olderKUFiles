var libscheduler_8c =
[
    [ "job_t", "structjob__t.html", null ],
    [ "scheduler_average_response_time", "libscheduler_8c.html#a005484fb08747739cd1a5fc4fab74bea", null ],
    [ "scheduler_average_turnaround_time", "libscheduler_8c.html#a1048ae9f687974cae1dd9bc5cf0e1752", null ],
    [ "scheduler_average_waiting_time", "libscheduler_8c.html#ad0e6ae66206f1643048da694be43e191", null ],
    [ "scheduler_clean_up", "libscheduler_8c.html#ab8a57679c04b7dad4ebae7ae181e2dac", null ],
    [ "scheduler_job_finished", "libscheduler_8c.html#ace4ad90ac1a942044165a6ab56229851", null ],
    [ "scheduler_new_job", "libscheduler_8c.html#a102ab9a6713a66a68933f84d0308cd2f", null ],
    [ "scheduler_quantum_expired", "libscheduler_8c.html#a3bc78e1ddd7eb1ba2285fa60599d38c1", null ],
    [ "scheduler_show_queue", "libscheduler_8c.html#a21c8603e838d15e7967ae0c637a66650", null ],
    [ "scheduler_start_up", "libscheduler_8c.html#a5dad2df1b25832a1438546974e337cbc", null ]
];