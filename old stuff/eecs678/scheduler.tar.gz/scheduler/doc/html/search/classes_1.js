var searchData=
[
  ['priqueue_5ft',['priqueue_t',['../structpriqueue__t.html',1,'']]]
];
