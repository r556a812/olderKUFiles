var structnode =
[
    [ "data", "structnode.html#ae82853bbf3b0d2b71de205ae40799555", null ],
    [ "next", "structnode.html#aa3e8aa83f864292b5a01210f4453fcc0", null ]
];