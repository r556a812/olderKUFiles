var examplesPage =
[
    [ "FCFS, 1 Core", "example1.html", null ],
    [ "FCFS, 2 Cores", "example2.html", null ],
    [ "RR2, 1 Core", "example3.html", null ]
];