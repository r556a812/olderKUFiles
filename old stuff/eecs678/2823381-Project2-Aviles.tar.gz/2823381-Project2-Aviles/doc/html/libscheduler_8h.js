var libscheduler_8h =
[
    [ "scheme_t", "libscheduler_8h.html#a4a9a6481e652361e21cee179b9a5412d", [
      [ "FCFS", "libscheduler_8h.html#a4a9a6481e652361e21cee179b9a5412da423cd86c32d4009579e138b098f06ba8", null ],
      [ "SJF", "libscheduler_8h.html#a4a9a6481e652361e21cee179b9a5412da8ade209ddd4ef30da88ba1c9780b5e33", null ],
      [ "PSJF", "libscheduler_8h.html#a4a9a6481e652361e21cee179b9a5412daf392608bc907145175a4c6b1576c4816", null ],
      [ "PRI", "libscheduler_8h.html#a4a9a6481e652361e21cee179b9a5412dae264bec919d7a867c667004363cde615", null ],
      [ "PPRI", "libscheduler_8h.html#a4a9a6481e652361e21cee179b9a5412dacd6ac2b38866367e49976a33de2b1542", null ],
      [ "RR", "libscheduler_8h.html#a4a9a6481e652361e21cee179b9a5412daea4586c054afe1678864fa75dfb1787d", null ]
    ] ],
    [ "scheduler_average_response_time", "libscheduler_8h.html#a005484fb08747739cd1a5fc4fab74bea", null ],
    [ "scheduler_average_turnaround_time", "libscheduler_8h.html#a1048ae9f687974cae1dd9bc5cf0e1752", null ],
    [ "scheduler_average_waiting_time", "libscheduler_8h.html#ad0e6ae66206f1643048da694be43e191", null ],
    [ "scheduler_clean_up", "libscheduler_8h.html#ab8a57679c04b7dad4ebae7ae181e2dac", null ],
    [ "scheduler_job_finished", "libscheduler_8h.html#ace4ad90ac1a942044165a6ab56229851", null ],
    [ "scheduler_new_job", "libscheduler_8h.html#a102ab9a6713a66a68933f84d0308cd2f", null ],
    [ "scheduler_quantum_expired", "libscheduler_8h.html#a3bc78e1ddd7eb1ba2285fa60599d38c1", null ],
    [ "scheduler_show_queue", "libscheduler_8h.html#a21c8603e838d15e7967ae0c637a66650", null ],
    [ "scheduler_start_up", "libscheduler_8h.html#a5dad2df1b25832a1438546974e337cbc", null ],
    [ "avg", "libscheduler_8h.html#a3df769aecb07ec4efe0aaa22b7d286ea", null ],
    [ "last_job_added", "libscheduler_8h.html#ad3e3e0332ce741afb968bcc5cbf30d59", null ],
    [ "num_jobs", "libscheduler_8h.html#a360cbba1dcbaf004006058af962a140d", null ],
    [ "resonse_time", "libscheduler_8h.html#af559e19ffbacc52a294ed047e8f06df6", null ]
];