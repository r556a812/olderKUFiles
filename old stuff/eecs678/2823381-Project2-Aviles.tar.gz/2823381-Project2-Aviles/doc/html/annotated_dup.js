var annotated_dup =
[
    [ "job_t", "structjob__t.html", "structjob__t" ],
    [ "node", "structnode.html", "structnode" ],
    [ "priqueue_t", "structpriqueue__t.html", "structpriqueue__t" ]
];