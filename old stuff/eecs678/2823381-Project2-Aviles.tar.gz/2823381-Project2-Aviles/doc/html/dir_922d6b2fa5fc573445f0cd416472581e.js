var dir_922d6b2fa5fc573445f0cd416472581e =
[
    [ "libpriqueue.c", "libpriqueue_8c.html", "libpriqueue_8c" ],
    [ "libpriqueue.h", "libpriqueue_8h.html", "libpriqueue_8h" ]
];