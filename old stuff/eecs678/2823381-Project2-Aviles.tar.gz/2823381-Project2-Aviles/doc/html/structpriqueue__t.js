var structpriqueue__t =
[
    [ "compare", "structpriqueue__t.html#aadd33c216ccbbc1307a8dfdaca4c4f27", null ],
    [ "front", "structpriqueue__t.html#a217fff61901b195e04d93446e7c86406", null ],
    [ "size", "structpriqueue__t.html#ac7e82606991e942be13687b6f6232996", null ]
];