var structjob__t =
[
    [ "job_number", "structjob__t.html#acab2869f53a44b411ecb3009a7424280", null ],
    [ "priority", "structjob__t.html#a173228d1697d71307f6538b2914f7156", null ],
    [ "remaining_time", "structjob__t.html#a7eb75e48c9c3388898ae752dc5427602", null ],
    [ "running_time", "structjob__t.html#a710d2b8b8d506de75276806d768f4ce8", null ],
    [ "time", "structjob__t.html#a9f0c30e752862aa7d81f618a68d3a33d", null ],
    [ "time2", "structjob__t.html#a02450fe0f0e83057444f6b56a2ccc5d3", null ]
];