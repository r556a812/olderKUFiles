/*
 * speaker.h
 *
 *  Created on: Feb 3, 2016
 *      Author: raviles
 */

#ifndef EECS_388_P2_SRC_SPEAKER_H_
#define EECS_388_P2_SRC_SPEAKER_H_

/*
 *  The initialization and execution functions of the SPEAKER
 */
extern void SPEAKERInit();
extern void SPEAKERExec();

#endif /* EECS_388_P2_SRC_SPEAKER_H_ */
